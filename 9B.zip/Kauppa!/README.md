Hei,

Yritän tässä parhaani mukaan saada tolkkua bootstarpin ihmeellisestä maailmasta.